<!DOCTYPE html>

<html>
<head>
<title>Sign Up Form</title>
</head>
<body>
<center>
<br>
<h1>Job Registeration Form</h1>
<br><br>
<form name="reg" action="add1.php" method="POST" >
<table>
<tr>
<td>Name :</td>
<td><input type="text" name="name" value="" required/></td>
</tr>
<tr>
<td>Father Name :</td>
<td><input type="text" name="father_name" value="" required/></td>
</tr>
<tr>
<td>Address :</td>
<td><input type="text" name="address" value="" required/></td>
</tr>
<tr>
<td>Gender :</td>
<td><select name="gender">
<option value="">Select Value</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
</td>
</tr>
<tr>
<td>State :</td>
<td><select name="state">
<option value="">Select Value</option>
<option value="India">India</option>
<option value="America">America</option>
</td>
</tr>
<tr>
<td>City :</td>
<td><select name="city">
<option value="">Select Value</option>
<option value="Pollachi">Pollachi</option>
<option value="CBE">CBE</option>
</td>
</tr>
<tr>
<td>Date Of Birth :</td>
<td><input type="date" name="dob" value=""></td>
</tr>
<tr>
<td>Pincode :</td>
<td><input type="text" name="pin" value=""></td>
</tr>
<tr>
<td>Name of the Post :</td>
<td><select name="post">
<option value=""></option>
<option value="computer">Computer Operator & Pragramming Assistant</option>
<option value="desiger">Designer</option>
<option value="marketing">Marketing</option>
</select>
</td>
</tr>
<tr>
<td>Email ID :</td>
<td><input type="email" name="email" value="" /></td>
</tr>
<tr>
<td>Password :</td>
<td><input type="password" name="psw" value="" /></td>
</tr>
<tr>
<td><input type="submit" value="Register" class="submit" name="submit" id="submit" /></td>
</tr>
</table>
</form>
</center>
</body>
</html>