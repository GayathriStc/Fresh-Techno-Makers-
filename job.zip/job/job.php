<!DOCTYPE html>

<html>
<head>
<title>Sign Up Form</title>
</head>
<body>
<center>
<br>
<h1>Available Job Information</h1>
<br>
<form name="job" action="" method="POST" >
<table>
<tr>
<td><b>ART PRODUCTION MANAGER</b>
<p>Art production managers or traffic managers oversee the production aspect of art to 
improve efficiency and cost effectiveness. Art production managers supervise artists or advise the supervisors of artists. 
Creative directors and art directors often assume the role of art production managers, 
especially when production cost is not a critical enough concern to designate a manager for the specific role.</p>
<p><b>Experience:</b>0 - 2 Years.</p>
<p><b>Job Location:</b> Pollachi </p>
<p><b>Salary:</b> 10,000 /- Month.</p>
<input type="submit" value="Apply Now" class="submit" name="submit" /></td>
</tr>
<tr>
<td><b>BRAND IDENTITY DEVELOPER</b>
<p>Brand identity Developer or traffic managers oversee the production aspect of art to 
improve efficiency and cost effectiveness. Brand identity Developer supervise artists or advise the supervisors of artists. 
Creative directors and art directors often assume the role of art production managers, 
especially when production cost is not a critical enough concern to designate a manager for the specific role.</p>
<p><b>Experience:</b>0 - 3 Years.</p>
<p><b>Job Location:</b> Pollachi </p>
<p><b>Salary:</b> 12,000 /- Month.</p>
<input type="submit" value="Apply Now" class="submit" name="submit" /></td>
</tr>
</table>
</form>
</center>
</body>
</html>