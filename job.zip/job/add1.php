<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

/* mysql> use jobport
Database changed
mysql> drop table job;
Query OK, 0 rows affected (0.04 sec)

mysql> create table job(name varchar(20),fname varchar(20),addr varchar(20),gender 
varchar(10),state varchar(20),city varchar(20),dob date,pin varchar(10),post
varchar(20),email varchar(20),psw varchar(20));
Query OK, 0 rows affected (0.06 sec)

mysql> */


$link = mysqli_connect("localhost", "root", "", "jobport");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$nm = mysqli_real_escape_string($link, $_REQUEST['name']);
$fn = mysqli_real_escape_string($link, $_REQUEST['father_name']);
$addr = mysqli_real_escape_string($link, $_REQUEST['address']);
$gender = mysqli_real_escape_string($link, $_REQUEST['gender']);
$state = mysqli_real_escape_string($link, $_REQUEST['state']);
$city = mysqli_real_escape_string($link, $_REQUEST['city']);
$dob = mysqli_real_escape_string($link, $_REQUEST['dob']);
$pincode = mysqli_real_escape_string($link, $_REQUEST['pin']);
$post = mysqli_real_escape_string($link, $_REQUEST['post']);
$email = mysqli_real_escape_string($link, $_REQUEST['email']);
$psw = mysqli_real_escape_string($link, $_REQUEST['psw']);

 
// attempt insert query execution
$sql = "INSERT INTO job (name, fname, addr, gender, state, city, dob, pin, post, email, psw) VALUES ('$nm', '$fn', '$addr', '$gender', '$state', '$city', '$dob', '$pincode', '$post', '$email', '$psw')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
	header("Location: job.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>

