﻿Imports System.Data
Imports System.Data.OleDb
Partial Class movieDet
    Inherits System.Web.UI.Page
    Dim con As New OleDb.OleDbConnection
    Dim da As New OleDb.OleDbDataAdapter
    Dim cmd As New OleDb.OleDbCommand
    Dim ds As New DataSet
    Dim q As String
    Dim i As Integer
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Panel2.Visible = True
        LinkButton2.Visible = True
        LinkButton1.Visible = False
    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        Panel2.Visible = False
        LinkButton2.Visible = False
        LinkButton1.Visible = True
    End Sub

    Protected Sub LinkButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton4.Click
        DropDownList4.Visible = True
        Label1.Visible = False
        Panel1.Visible = True
        Button1.Visible = False
        Button2.Visible = True
        Button3.Visible = True
        Button4.Visible = True
        Button5.Visible = True
        LinkButton1.Visible = False
        LinkButton2.Visible = False
        Panel2.Visible = True
    End Sub

    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        Panel1.Visible = True
        Label1.Visible = True
        DropDownList4.Visible = False
        Button1.Visible = True
        Button2.Visible = False
        Button3.Visible = False
        Button4.Visible = False
        Button5.Visible = False
        LinkButton1.Visible = True
        'LinkButton2.Visible = True
        Panel2.Visible = False
        Call autoid()
    End Sub
    Private Sub autoid()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Dim TEM As String
        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb")
        cmd.Connection = con
        con.Open()
        Dim num As String
        cmd.CommandText = "select max(TID) from MOVIE_DETAILS"
        If IsDBNull(cmd.ExecuteScalar) Then
            num = "T1"
            Label1.Text = num

        Else
            num = cmd.ExecuteScalar
            Dim output As String = New String((From c As Char In num Select c Where Char.IsDigit(c)).ToArray())
            TEM = New String((From c As Char In num Select c Where Char.IsLetter(c)).ToArray())
            output = output + 1
            Label1.Text = TEM + output
        End If
        cmd.Dispose()
        con.Close()
        con.Dispose()
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "insert into MOVIE_DETAILS values('" & Label1.Text & "','" & TextBox1.Text & "','" & TextBox2.Text & "'," & TextBox4.Text & ",'" & Label2.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "'," & TextBox7.Text & "," & TextBox8.Text & "," & TextBox9.Text & ")"
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        MsgBox("RECORDED ADDED SUCCESSFULLY", MsgBoxStyle.Information)
        Call CLEAR()
        Call autoid()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        con = New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb"))
        con.Open()
        Label2.Text = Now.Date
    End Sub
    Protected Sub CLEAR()
        TextBox1.Text = ""
        TextBox2.Text = ""
        'TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        TextBox9.Text = ""
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "select * from MOVIE_DETAILS where TID='" & DropDownList4.Text & "' "
        da.SelectCommand = New OleDb.OleDbCommand(q, con)
        da.Fill(ds)
        da.Dispose()
        For Me.i = 0 To ds.Tables(0).Rows.Count - 1
            If ds.Tables(0).Rows(i).Item(0) = DropDownList4.Text Then
                TextBox1.Text = ds.Tables(0).Rows(i).Item(1)
                TextBox2.Text = ds.Tables(0).Rows(i).Item(2)
                TextBox4.Text = ds.Tables(0).Rows(i).Item(3)
                Label2.Text = ds.Tables(0).Rows(i).Item(4)
                TextBox5.Text = ds.Tables(0).Rows(i).Item(5)
                TextBox6.Text = ds.Tables(0).Rows(i).Item(6)
                TextBox7.Text = ds.Tables(0).Rows(i).Item(7)
                TextBox8.Text = ds.Tables(0).Rows(i).Item(8)
                TextBox9.Text = ds.Tables(0).Rows(i).Item(9)
            End If
              Next 
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "update MOVIE_DETAILS set TNAME='" & TextBox1.Text & "',CITY='" & TextBox2.Text & "',MOB_NO=" & TextBox4.Text & ",MOV_DATE='" & Label2.Text & "',MOVIE_NAME='" & TextBox5.Text & "',MOVIE_SUMMARY='" & TextBox6.Text & "',TOT_NO_OF_SEATS=" & TextBox7.Text & ",SEATS_AVAILABLE=" & TextBox8.Text & ",AMT=" & TextBox9.Text & " where TID='" & DropDownList4.Text & "'"
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        MsgBox("RECORDED UPDATED SUCCESSFULLY", MsgBoxStyle.Information)
        Call CLEAR()
    End Sub

    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button5.Click
        Call CLEAR()
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "delete * from MOVIE_DETAILS where TID='" & DropDownList4.Text & "'"
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        MsgBox("RECORDED DELETED SUCCESSFULLY", MsgBoxStyle.Information)
        Call CLEAR()
    End Sub

    Protected Sub LinkButton5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton5.Click
        Response.Redirect("ADMINPAGE.aspx")
    End Sub

    
End Class
