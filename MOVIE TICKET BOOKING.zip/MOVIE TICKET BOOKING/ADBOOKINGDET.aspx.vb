﻿
Partial Class ADBOOKINGDET
    Inherits System.Web.UI.Page

End Class
