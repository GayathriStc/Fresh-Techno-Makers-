﻿Imports System.Data
Partial Class AFREG
    Inherits System.Web.UI.Page
    Dim con As New OleDb.OleDbConnection
    Dim da As New OleDb.OleDbDataAdapter
    Dim cmd As New OleDb.OleDbCommand
    Dim ds As New DataSet
    Dim q As String
    Dim i As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        con = New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb"))
        con.Open()
        Label1.Text = (Session("Eid"))
        q = "select * from USER_TAB where EID='" & Label1.Text & "' "
        da.SelectCommand = New OleDb.OleDbCommand(q, con)
        da.Fill(ds)
        da.Dispose()
        For Me.i = 0 To ds.Tables(0).Rows.Count - 1
            If ds.Tables(0).Rows(i).Item(2) = Label1.Text Then
                Label2.Text = ds.Tables(0).Rows(i).Item(0)
                Label3.Text = ds.Tables(0).Rows(i).Item(1)
            End If
        Next
        Session("nm") = Label3.Text
        Session("uid") = Label2.Text
    End Sub
End Class
