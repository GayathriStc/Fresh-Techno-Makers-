﻿Imports System.Data
Imports System.Data.OleDb
Partial Class THEATRE
    Inherits System.Web.UI.Page
    Dim con As New OleDb.OleDbConnection
    Dim da As New OleDb.OleDbDataAdapter
    Dim cmd As New OleDb.OleDbCommand
    Dim ds As New DataSet
    Dim q As String
    Dim i As Integer

    Private Sub autoid()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Dim TEM As String
        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb")
        cmd.Connection = con
        con.Open()
        Dim num As String
        cmd.CommandText = "select max(TID) from THEATRE_INFO"
        If IsDBNull(cmd.ExecuteScalar) Then
            num = "T1"
            Label1.Text = num

        Else
            num = cmd.ExecuteScalar
            Dim output As String = New String((From c As Char In num Select c Where Char.IsDigit(c)).ToArray())
            TEM = New String((From c As Char In num Select c Where Char.IsLetter(c)).ToArray())
            output = output + 1
            Label1.Text = TEM + output
        End If
        cmd.Dispose()
        con.Close()
        con.Dispose()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Panel1.Visible = True
        Panel2.Visible = True
        Button1.Visible = True
        Button2.Visible = False
        Button3.Visible = False
        Button4.Visible = False
        Button5.Visible = False
        Panel2.BorderStyle = BorderStyle.None
        DropDownList1.Visible = False
        Label1.Visible = True
    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        Panel1.Visible = True
        Panel2.Visible = True
        Button1.Visible = False
        Button2.Visible = True
        Button3.Visible = True
        Button4.Visible = True
        Button5.Visible = True
        DropDownList1.Visible = True
        Label1.Visible = False
        Panel2.BorderStyle = BorderStyle.Inset
    End Sub
End Class
