﻿
Partial Class ADLOGIN
    Inherits System.Web.UI.Page

    
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "admin" And TextBox2.Text = "adminpsw" Then
            MsgBox("LOGGED SUCCESSFULLY", MsgBoxStyle.Information)
            Call clear()
            Response.Redirect("ADMINPAGE.aspx")
        ElseIf TextBox1.Text = "" Or TextBox2.Text = "" Then
            'MsgBox("PLEASE ENTER THE USER NAME AND PASSWORD !!!")
            Label1.Text = "PLEASE ENTER THE USER NAME AND PASSWORD !!!"
            Call clear()
        Else
            'MsgBox("INVALID USER NAME AND PASSWORD...TRY AGAIN")
            Label1.Text = "INVALID USER NAME AND PASSWORD...TRY AGAIN"
            Call clear()
        End If
    End Sub
    Protected Sub clear()
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub
End Class
