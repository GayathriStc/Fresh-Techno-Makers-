﻿Imports System.Data
Imports System.Data.OleDb
Partial Class Default3
    Inherits System.Web.UI.Page
    Dim con As New OleDb.OleDbConnection
    Dim da As New OleDb.OleDbDataAdapter
    Dim cmd As New OleDb.OleDbCommand
    Dim ds As New DataSet
    Dim q As String
    Dim i As Integer
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Panel1.Visible = True
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        con = New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb"))
        con.Open()
        Label4.Text = Now.Date
        Label1.Text = Session("nm")
        Label2.Text = Session("uid")
        Call autoid()
    End Sub
    Private Sub autoid()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb")
        cmd.Connection = con
        con.Open()
        Dim num As Integer
        cmd.CommandText = "select max(BID) from BOOKING"
        If IsDBNull(cmd.ExecuteScalar) Then
            num = 1
            Label3.Text = num

        Else
            num = cmd.ExecuteScalar + 1
            Label3.Text = num
        End If
        cmd.Dispose()
        con.Close()
        con.Dispose()
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "select * from MOVIE_DETAILS where TID='" & DropDownList2.Text & "' "
        da.SelectCommand = New OleDb.OleDbCommand(q, con)
        da.Fill(ds)
        da.Dispose()
        For Me.i = 0 To ds.Tables(0).Rows.Count - 1
            If ds.Tables(0).Rows(i).Item(0) = DropDownList2.Text Then
                TextBox1.Text = ds.Tables(0).Rows(i).Item(1)
                TextBox2.Text = ds.Tables(0).Rows(i).Item(2)
                TextBox3.Text = ds.Tables(0).Rows(i).Item(5)
                TextBox4.Text = ds.Tables(0).Rows(i).Item(9)
                TextBox5.Text = ds.Tables(0).Rows(i).Item(7)
                TextBox7.Text = ds.Tables(0).Rows(i).Item(8)
            End If
        Next
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim a, b, C As Double
        a = TextBox4.Text
        b = TextBox8.Text
        If DropDownList4.SelectedIndex = 0 Then
            C = 100 + a
        ElseIf DropDownList4.SelectedIndex = 1 Then
            C = 90 + a
        ElseIf DropDownList4.SelectedIndex = 2 Then
            C = 70 + a
        ElseIf DropDownList4.SelectedIndex = 3 Then
            C = 50 + a
        ElseIf DropDownList4.SelectedIndex = 4 Then
            C = a
        End If
        TextBox9.Text = (b * C)
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "insert into BOOKING values('" & Label3.Text & "','" & Label2.Text & "','" & Label1.Text & "','" & DropDownList2.Text & "','" & TextBox3.Text & "','" & DropDownList3.Text & "','" & DropDownList4.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" & Label4.Text & "')"
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        MsgBox("TICKETS BOOKED SUCCESSFULLY." & " " & "YOUR BOOKING ID IS :" & " " & Label3.Text, MsgBoxStyle.Information)
        TextBox10.Text = Val(TextBox7.Text) - Val(TextBox8.Text)
        q = "update MOVIE_DETAILS set SEATS_AVAILABLE=" & TextBox10.Text & " where TID='" & DropDownList2.Text & "' "
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        Call clear()
        Call autoid()
        con.Close()
    End Sub
    Protected Sub clear()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        TextBox9.Text = ""
        'TextBox10.Text = ""
    End Sub

    'Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
    '  If con.State = ConnectionState.Closed Then
    '   con.Open()
    '  End If
    '   q = "delete from BOOKING where UID='" & Label2.Text & "' "
    '    cmd = New OleDb.OleDbCommand(q, con)
    '  cmd.ExecuteNonQuery()
    '  MsgBox("BOOKING CANCELED SUCCESSFULLY")
    ' TextBox10.Text = Val(TextBox7.Text) + Val(TextBox8.Text)
    '  q = "update MOVIE_DETAILS set SEATS_AVAILABLE=" & TextBox10.Text & " where TID='" & DropDownList2.Text & "' "
    '   cmd = New OleDb.OleDbCommand(q, con)
    '  cmd.ExecuteNonQuery()
    '  Call clear()
    '  con.Close()
    ' End Sub
End Class
