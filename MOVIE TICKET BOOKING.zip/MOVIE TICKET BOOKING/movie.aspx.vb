﻿Imports System.Data
Imports System.Data.OleDb
Partial Class movie
    Inherits System.Web.UI.Page
    Dim con As New OleDb.OleDbConnection
    Dim da As New OleDb.OleDbDataAdapter
    Dim cmd As New OleDb.OleDbCommand
    Dim ds As New DataSet
    Dim q As String
    Dim i As Integer

    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button5.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "insert into MOVIE values('" & Label1.Text & "','" & Label2.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "' )"
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        MsgBox("RECORDED ADDED SUCCESSFULLY", MsgBoxStyle.Information)
        Call CLEAR()
        Call autoid()
    End Sub
    Protected Sub CLEAR()
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub
    Private Sub autoid()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb")
        cmd.Connection = con
        con.Open()
        Dim num As Integer
        cmd.CommandText = "select max(SNO) from MOVIE"
        If IsDBNull(cmd.ExecuteScalar) Then
            num = 1
            Label1.Text = num

        Else
            num = cmd.ExecuteScalar + 1
            Label1.Text = num
        End If
        cmd.Dispose()
        con.Close()
        con.Dispose()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        con = New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb"))
        con.Open()
        Call autoid()
        Label2.Text = Now.Date
        ' Button1.Visible = False
        'Button2.Visible = False
        'Button3.Visible = False
        'Button4.Visible = False
        'Panel1.Visible = False
        'Panel2.Visible = False
        'Label1.Visible = True
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "select * from MOVIE where SNO=" & DropDownList1.Text & " "
        da.SelectCommand = New OleDb.OleDbCommand(q, con)
        da.Fill(ds)
        da.Dispose()
        For Me.i = 0 To ds.Tables(0).Rows.Count - 1
            If ds.Tables(0).Rows(i).Item(0) = DropDownList1.Text Then
                TextBox2.Text = ds.Tables(0).Rows(i).Item(2)
                TextBox3.Text = ds.Tables(0).Rows(i).Item(3)
                Label2.Text = ds.Tables(0).Rows(i).Item(1)
            Else
                MsgBox("PLEASE CHECK THE MOVIE NUMBER.", MsgBoxStyle.Exclamation)
            End If
        Next
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        Call CLEAR()
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "UPDATE MOVIE SET ENTRY_DATE='" & Label2.Text & "',MOVIE_NAME='" & TextBox2.Text & "',SUMMARY='" & TextBox3.Text & "' where SNO=" & DropDownList1.Text & " "
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        MsgBox("RECORDED UPDATED SUCCESSFULLY", MsgBoxStyle.Information)
        Call CLEAR()
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "delete * from MOVIE where SNO=" & DropDownList1.Text & " "
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        MsgBox("RECORDED DELETED SUCCESSFULLY", MsgBoxStyle.Information)
        Call CLEAR()
    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        Button5.Visible = True
        Label1.Visible = True
        Panel1.Visible = True
        Panel2.Visible = False
        DropDownList1.Visible = False
        Button1.Visible = False
        Button2.Visible = False
        Button3.Visible = False
        Button4.Visible = False
    End Sub

    Protected Sub LinkButton5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton5.Click
        Panel2.Visible = True
    End Sub

    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        Panel1.Visible = True
        Panel2.Visible = True
        Button1.Visible = True
        Button2.Visible = True
        Button3.Visible = True
        DropDownList1.Visible = True
        Button4.Visible = True
        Button5.Visible = False
        Label1.Visible = False
        'Panel1.Visible = False
        LinkButton5.Visible = True
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Panel3.Visible = True
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If

    End Sub

    Protected Sub LinkButton6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton6.Click
        LinkButton1.Visible = True
        'LinkButton6.Visible = False
        Panel3.Visible = False
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If

    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
    End Sub

    
    Protected Sub LinkButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton4.Click
        Response.Redirect("ADMINPAGE.aspx")
    End Sub
End Class
