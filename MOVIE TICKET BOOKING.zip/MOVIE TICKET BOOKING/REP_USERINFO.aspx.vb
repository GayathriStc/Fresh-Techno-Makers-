﻿
Partial Class REP_USERINFO
    Inherits System.Web.UI.Page

    Protected Sub CrystalReportViewer1_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles CrystalReportViewer1.Init

    End Sub
End Class
