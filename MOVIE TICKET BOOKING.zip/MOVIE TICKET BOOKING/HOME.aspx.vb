﻿
Partial Class HOME
    Inherits System.Web.UI.Page

End Class
