﻿Imports System.Data
Partial Class CANBOOK
    Inherits System.Web.UI.Page
    Dim con As New OleDb.OleDbConnection
    Dim da As New OleDb.OleDbDataAdapter
    Dim cmd As New OleDb.OleDbCommand
    Dim dr As OleDb.OleDbDataReader
    Dim ds As New DataSet
    Dim q As String
    Dim i As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        con = New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb"))
        con.Open()
        Label1.Text = Session("uid")
        Panel1.Visible = False
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Panel1.Visible = True
        q = "select * from BOOKING where BID='" & DropDownList1.Text & "' "
        da.SelectCommand = New OleDb.OleDbCommand(q, con)
        da.Fill(ds)
        da.Dispose()
        For Me.i = 0 To ds.Tables(0).Rows.Count - 1
            If ds.Tables(0).Rows(i).Item(0) = DropDownList1.Text Then
                Text_no_tic.Text = ds.Tables(0).Rows(i).Item(7)
                TextTID.Text = ds.Tables(0).Rows(i).Item(3)
            End If
        Next
       
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "select * from MOVIE_DETAILS where TID='" & TextTID.Text & "' "
        da.SelectCommand = New OleDb.OleDbCommand(q, con)
        da.Fill(ds)
        da.Dispose()
        For Me.i = 0 To ds.Tables(0).Rows.Count - 1
            If ds.Tables(0).Rows(i).Item(0) = TextTID.Text Then
                TextAvail.Text = ds.Tables(0).Rows(i).Item(8)
            End If
        Next
        q = "delete from BOOKING where BID='" & DropDownList1.Text & "' "
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        MsgBox("BOOKING CANCELED SUCCESSFULLY")
        TextRes.Text = Val(TextAvail.Text) + Val(Text_no_tic.Text)
        q = "update MOVIE_DETAILS set SEATS_AVAILABLE=" & TextRes.Text & " where TID='" & TextTID.Text & "' "
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        'Call clear()
        con.Close()
    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "select * from BOOKING where UID='" & Label1.Text & "' "
        cmd = New OleDb.OleDbCommand(q, con)
        dr = cmd.ExecuteReader()
        While (dr.Read())
            DropDownList1.Items.Add(dr.GetValue(0).ToString())
        End While
        dr.Close()
        Panel3.Visible = True
    End Sub
End Class
