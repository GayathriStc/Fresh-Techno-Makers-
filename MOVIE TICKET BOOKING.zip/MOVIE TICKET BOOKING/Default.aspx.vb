﻿Imports System.Data
Imports System.Data.OleDb
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim con As New OleDb.OleDbConnection
    Dim da As New OleDb.OleDbDataAdapter
    Dim cmd As New OleDb.OleDbCommand
    Dim ds As New DataSet
    Dim q As String
    Dim i As Integer
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        q = "insert into USER_TAB values('" & Label1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "')"
        cmd = New OleDb.OleDbCommand(q, con)
        cmd.ExecuteNonQuery()
        MsgBox("REGISTRATION COMPLETED SUCCESSFULLY", MsgBoxStyle.Information)
        Call clear()
        'Call autoid()
        Response.Redirect("Default4.aspx")
        con.Close()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        con = New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb"))
        con.Open()
        Call autoid()
    End Sub
    Private Sub autoid()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data source=" & Server.MapPath("MOVIE.mdb")
        cmd.Connection = con
        con.Open()
        Dim num As Integer
        cmd.CommandText = "select max(UID) from USER_TAB"
        If IsDBNull(cmd.ExecuteScalar) Then
            num = 1
            Label1.Text = num

        Else
            num = cmd.ExecuteScalar + 1
            Label1.Text = num
        End If
        cmd.Dispose()
        con.Close()
        con.Dispose()
    End Sub
    Protected Sub clear()
        Label1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub
End Class
