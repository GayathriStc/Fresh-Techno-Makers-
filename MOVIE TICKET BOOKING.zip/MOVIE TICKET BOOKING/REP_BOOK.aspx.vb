﻿Imports System.Data
Imports CrystalDecisions.CrystalReports.Engine
Imports System.Data.OleDb
Partial Class REP_BOOK
    Inherits System.Web.UI.Page
    Dim con As OleDb.OleDbConnection
    Dim cmd As OleDb.OleDbCommand
    Dim da As OleDb.OleDbDataAdapter
    Dim ds As DataSet

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Dim filepath As String = "E:\MOVIE TICKET BOOKING\CrystalReport1_booking.rpt"
        Dim file As New CrystalDecisions.CrystalReports.Engine.ReportDocument
        ds = New DataSet
        Dim q As String
        q = "select * from BOOKING where TID='" & DropDownList1.Text & "'"
        da = New OleDbDataAdapter(q, con)
        da.Fill(ds)
        file.Load(filepath)
        file.SetDataSource(ds.Tables(0))
        CrystalReportViewer1.ReportSource = file
        CrystalReportViewer1.Visible = True
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        con = New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;data source=" & Server.MapPath("MOVIE.mdb"))
        con.Open()
        CrystalReportViewer1.Visible = False
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim cryrpt As New ReportDocument
        cryrpt.Load("E:\MOVIE TICKET BOOKING\CrystalReport1_booking.rpt")
        CrystalReportViewer1.ReportSource = cryrpt
        'CrystalReportViewer1.Refresh()
        CrystalReportViewer1.Visible = True
    End Sub
End Class
