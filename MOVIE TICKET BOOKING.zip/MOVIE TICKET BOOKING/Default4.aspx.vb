﻿Imports System.Data.OleDb
Imports System.Data
Partial Class Default4
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim connstring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Server.MapPath("MOVIE.mdb") & ";"
        Dim qrystring As String = "SELECT EID,PHNO FROM USER_TAB where EID = '" & TextBox1.Text & "' ;"
        Dim objconn As New OleDbConnection(connstring)
        Dim objcmd As New OleDbCommand(qrystring, objconn)
        Dim myreader As OleDbDataReader
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("PLEASE ENTER THE VALUES")
        Else
            Try
                Dim gotuser As Boolean = False
                objconn.Open()
                myreader = objcmd.ExecuteReader
                While myreader.Read
                    If myreader.Item("EID") = TextBox1.Text And myreader.Item("PHNO") = TextBox2.Text Then
                        gotuser = True

                    End If
                End While
                myreader.Close()
                If gotuser = False Then
                    MsgBox("YOU MUST REGISTER YOUR NAME... ")
                    TextBox1.Text = ""
                    TextBox2.Text = ""
                Else
                    MsgBox("LOGGED SUCCESSFULLY", MsgBoxStyle.Information)
                    Session("Eid") = TextBox1.Text
                    Response.Redirect("AFREG.aspx")
                End If
            Catch ex As Exception
            Finally
                objconn.Close()
            End Try
        End If
    End Sub
End Class
