﻿
Partial Class ADMINPAGE
    Inherits System.Web.UI.Page

End Class
